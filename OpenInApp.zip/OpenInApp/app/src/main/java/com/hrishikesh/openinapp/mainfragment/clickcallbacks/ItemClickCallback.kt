package com.hrishikesh.openinapp.mainfragment.clickcallbacks

import com.hrishikesh.openinapp.mainfragment.MainViewModel
import com.hrishikesh.openinapp.mainfragment.util.TabSelectionEnum

class ItemClickCallback(val viewModel: MainViewModel) {
    fun changeTab(selectionEnum: TabSelectionEnum){
        viewModel.changeTab(selectionEnum)
    }
}