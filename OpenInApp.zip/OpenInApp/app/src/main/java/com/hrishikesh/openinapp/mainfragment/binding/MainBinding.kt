package com.hrishikesh.openinapp.mainfragment.binding

import android.graphics.drawable.PictureDrawable
import android.util.Log
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.imageview.ShapeableImageView
import com.hrishikesh.openinapp.R
import com.hrishikesh.openinapp.mainfragment.util.TabSelectionEnum
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@BindingAdapter("tabSelection")
fun tabSelection(textView: TextView, tabSelection: TabSelectionEnum) {
    when (tabSelection) {
        TabSelectionEnum.TOP_LINKS -> {
            if (textView.id.equals(R.id.topLink)) {
                textView.background =
                    ContextCompat.getDrawable(textView.context, R.drawable.tab_selection_bg)
                textView.setTextColor(ContextCompat.getColor(textView.context, R.color.white))
            } else {
                textView.background = null
                textView.setTextColor(
                    ContextCompat.getColor(
                        textView.context,
                        R.color.unSelectedTabColor
                    )
                )
            }
        }

        TabSelectionEnum.RECENT_LINKS -> {
            if (textView.id.equals(R.id.recentLink)) {
                textView.background =
                    ContextCompat.getDrawable(textView.context, R.drawable.tab_selection_bg)
                textView.setTextColor(ContextCompat.getColor(textView.context, R.color.white))
            } else {
                textView.background = null
                textView.setTextColor(
                    ContextCompat.getColor(
                        textView.context,
                        R.color.unSelectedTabColor
                    )
                )
            }
        }
    }
}

@BindingAdapter("setText")
fun setText(textView: TextView, count: Int?) {
    textView.text = "$count"
}

@BindingAdapter("setDateText")
fun setDateText(textView: TextView, count: Int?) {
    val hour = SimpleDateFormat("HH", Locale.getDefault()).format(Date())
    when (hour.toInt()) {
        in 0..11 -> textView.text = "Good Morning"
        in 12..17 -> textView.text = "Good Afternoon"
        else -> textView.text = "Good Evening"
    }
}

@BindingAdapter("imageUrl")
fun loadImageWithGlide(imageView: AppCompatImageView, imageUrl: String?) {
    if (imageUrl != null) {
        Glide.with(imageView.context)
            .load(imageUrl)
            .into(imageView)
    } else {
        Log.e("error", "error")
    }
}

@BindingAdapter("setDrawable")
fun setDrawable(imageView: ShapeableImageView, drawable: Int?) {
    when (drawable) {
        1 -> {
imageView.setImageDrawable(ContextCompat.getDrawable(imageView.context,R.drawable.ic_avatar_one))
        }

        2 -> {
            imageView.setImageDrawable(ContextCompat.getDrawable(imageView.context,R.drawable.ic_avatar_two))

        }

        3 -> {
            imageView.setImageDrawable(ContextCompat.getDrawable(imageView.context,R.drawable.ic_avatar_three))

        }
    }
}