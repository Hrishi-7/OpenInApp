package com.hrishikesh.openinapp.mainfragment.datamodels


import com.google.gson.annotations.SerializedName

data class MainDataModel(
    @SerializedName("applied_campaign")
    val appliedCampaign: Int?,
    @SerializedName("data")
    val data: Data?,
    @SerializedName("extra_income")
    val extraIncome: Double?,
    @SerializedName("links_created_today")
    val linksCreatedToday: Int?,
    @SerializedName("message")
    val message: String?,
    @SerializedName("startTime")
    val startTime: String?,
    @SerializedName("status")
    val status: Boolean?,
    @SerializedName("statusCode")
    val statusCode: Int?,
    @SerializedName("support_whatsapp_number")
    val supportWhatsappNumber: String?,
    @SerializedName("today_clicks")
    val todayClicks: Int?,
    @SerializedName("top_location")
    val topLocation: String?,
    @SerializedName("top_source")
    val topSource: String?,
    @SerializedName("total_clicks")
    val totalClicks: Int?,
    @SerializedName("total_links")
    val totalLinks: Int?
)

data class Data(
    @SerializedName("favourite_links")
    val favouriteLinks: List<Any?>?,
    @SerializedName("overall_url_chart")
    val overallUrlChart: LinkedHashMap<String,Int>?,
    @SerializedName("recent_links")
    val recentLinks: List<LinkModel?>?,
    @SerializedName("top_links")
    val topLinks: List<LinkModel?>?
)

data class LinkModel(
    @SerializedName("app")
    val app: String?,
    @SerializedName("created_at")
    val createdAt: String?,
    @SerializedName("domain_id")
    val domainId: String?,
    @SerializedName("is_favourite")
    val isFavourite: Boolean?,
    @SerializedName("original_image")
    val originalImage: String?,
    @SerializedName("smart_link")
    val smartLink: String?,
    @SerializedName("thumbnail")
    val thumbnail: Any?,
    @SerializedName("times_ago")
    val timesAgo: String?,
    @SerializedName("title")
    val title: String?,
    @SerializedName("total_clicks")
    val totalClicks: Int?,
    @SerializedName("url_id")
    val urlId: Int?,
    @SerializedName("url_prefix")
    val urlPrefix: Any?,
    @SerializedName("url_suffix")
    val urlSuffix: String?,
    @SerializedName("web_link")
    val webLink: String?
)
