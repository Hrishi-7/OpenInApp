package com.hrishikesh.openinapp.mainfragment.epoxy

import com.airbnb.epoxy.Carousel
import com.airbnb.epoxy.CarouselModel_
import com.airbnb.epoxy.Typed2EpoxyController
import com.airbnb.epoxy.group
import com.hrishikesh.openinapp.R
import com.hrishikesh.openinapp.mainfragment.clickcallbacks.ItemClickCallback
import com.hrishikesh.openinapp.mainfragment.datamodels.MainDataModel
import com.hrishikesh.openinapp.mainfragment.util.TabSelectionEnum

class EpoxyMainController(private val itemClickCallback: ItemClickCallback) :
    Typed2EpoxyController<MainDataModel?, TabSelectionEnum?>() {
    override fun buildModels(data1: MainDataModel?, data2: TabSelectionEnum?) {
        data1?.let {
            epoxyHeaderItem {
                id("header Item")
            }
            group {
                id("group")
                layout(R.layout.epoxy_controller_group)
                add(
                    EpoxyGraphItem_()
                        .id("graph item")
                )
                val popularVideoCarouselList = ArrayList<EpoxyCarouselModel_>()
                popularVideoCarouselList.add(
                    EpoxyCarouselModel_().id("carousel 1").data1(it.todayClicks.toString()).data2("Today's Clicks").drawable(1)
                )
                popularVideoCarouselList.add(
                    EpoxyCarouselModel_().id("carousel 2").data1(it.topLocation).data2("Top Location").drawable(2)
                )

                popularVideoCarouselList.add(
                    EpoxyCarouselModel_().id("carousel 3").data1(it.topSource).data2("Top Source").drawable(3)
                )

                Carousel.setDefaultGlobalSnapHelperFactory(null)
                add(
                    CarouselModel_()
                        .id(2)
                        .models(popularVideoCarouselList)
                        .padding(Carousel.Padding.dp(16, 0, 16, 8, 16))
                )
                add(
                    EpoxyTabSelectionItem_()
                        .id("tab Selection")
                        .itemClickCallback(this@EpoxyMainController.itemClickCallback)
                        .tabSelectionEnum(data2)
                )
                when (data2) {
                    TabSelectionEnum.TOP_LINKS -> {
                        it.data?.topLinks?.forEachIndexed { index, topLinkModel ->
                            add(
                                EpoxyLinkItem_()
                                    .id("topLink $index")
                                    .linkModel(topLinkModel)
                            )
                        }
                    }

                    TabSelectionEnum.RECENT_LINKS -> {
                        it.data?.recentLinks?.forEachIndexed { index, recentLinkModel ->
                            add(
                                EpoxyLinkItem_()
                                    .id("recentLink $index")
                                    .linkModel(recentLinkModel)
                            )
                        }
                    }

                    else -> {}
                }
                add(
                    EpoxyRecyclerBottomItem_()
                        .id("bottom Item")
                )
            }
        }
    }
}