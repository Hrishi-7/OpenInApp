package com.hrishikesh.openinapp.mainfragment.util

enum class TabSelectionEnum {
    TOP_LINKS,
    RECENT_LINKS
}