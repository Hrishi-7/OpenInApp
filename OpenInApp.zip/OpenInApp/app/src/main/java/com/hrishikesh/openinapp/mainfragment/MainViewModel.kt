package com.hrishikesh.openinapp.mainfragment

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hrishikesh.openinapp.mainfragment.datamodels.MainDataModel
import com.hrishikesh.openinapp.mainfragment.source.MainRemoteRepository
import com.hrishikesh.openinapp.mainfragment.util.TabSelectionEnum
import com.hrishikesh.openinapp.utilities.di.DispatcherModule
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.hrishikesh.openinapp.utilities.Result


@HiltViewModel
class MainViewModel @Inject constructor(
    private val mainRemoteRepository: MainRemoteRepository,
    @DispatcherModule.IoDispatcher val coroutineDispatcher: CoroutineDispatcher,
) : ViewModel() {

    private val _mainLiveData = MutableLiveData<MainDataModel>()
    val mainLiveData: LiveData<MainDataModel> = _mainLiveData

    private val _tabSelectionLiveData = MutableLiveData(TabSelectionEnum.TOP_LINKS)
    val tabSelectionLiveData: LiveData<TabSelectionEnum> = _tabSelectionLiveData


    init {
        getMainData()
    }

    private fun getMainData() {
//        updateLoadingState(Loading.LOADING, null, isListEmpty())
        viewModelScope.launch(coroutineDispatcher) {
            val response = mainRemoteRepository.getMainData()
            if (response is Result.Success) {
                response.data.let {
                    _mainLiveData.postValue(it)
                    Log.e(
                        "Data is",
                        it.toString()
                    )//
                    // updateLoadingState(Loading.COMPLETED, null, isListEmpty())
                }
            } else if (response is Result.Error) {
//                updateLoadingState(
//                    Result.Loading.ERROR,
//                    e = response.exception
//                )
                Log.e(
                    "Data is",
                    response.exception.toString()
                )
            }
        }
    }

    fun changeTab(selection: TabSelectionEnum) {
        _tabSelectionLiveData.postValue(selection)
    }
}