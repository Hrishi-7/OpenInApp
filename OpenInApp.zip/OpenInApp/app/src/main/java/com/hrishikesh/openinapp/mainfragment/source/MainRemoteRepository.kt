package com.hrishikesh.openinapp.mainfragment.source

import com.hrishikesh.openinapp.mainfragment.datamodels.MainDataModel
import com.hrishikesh.openinapp.utilities.di.DispatcherModule
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Header
import javax.inject.Inject
import com.hrishikesh.openinapp.utilities.Result
import com.hrishikesh.openinapp.utilities.CONSTANTS.Companion.MAIN_URL
import com.hrishikesh.openinapp.utilities.CONSTANTS.Companion.TOKEN
import retrofit2.http.Headers

class MainRemoteRepository @Inject constructor(
    retrofit: Retrofit,
    @DispatcherModule.IoDispatcher private val coroutineDispatcher: CoroutineDispatcher,
) {
    private val service = retrofit.create(MainRemoteInterface::class.java)

    suspend fun getMainData(): Result<MainDataModel> {
        return withContext(coroutineDispatcher) {
            try {
                val response = service.getMainData("Bearer $TOKEN")
                Result.Success(response)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }

    interface MainRemoteInterface {
        @Headers("Content-Type: application/json;charset=UTF-8")
        @GET(MAIN_URL)
        suspend fun getMainData(
            @Header("Authorization")  auth: String
        ): MainDataModel
    }
}