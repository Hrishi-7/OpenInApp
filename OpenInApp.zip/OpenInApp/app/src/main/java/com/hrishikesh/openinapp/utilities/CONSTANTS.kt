package com.hrishikesh.openinapp.utilities

public class CONSTANTS {
companion object{
    const val MAIN_URL="https://api.inopenapp.com/api/v1/dashboardNew"
    const val TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjU5MjcsImlhdCI6MTY3NDU1MDQ1MH0.dCkW0ox8tbjJA2GgUx2UEwNlbTZ7Rr38PVFJevYcXFI"
}
}