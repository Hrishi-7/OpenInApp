package com.hrishikesh.openinapp.mainfragment.epoxy

import android.annotation.SuppressLint
import androidx.databinding.ViewDataBinding
import com.airbnb.epoxy.DataBindingEpoxyModel
import com.airbnb.epoxy.EpoxyAttribute
import com.airbnb.epoxy.EpoxyModelClass
import com.airbnb.epoxy.databinding.BR
import com.hrishikesh.openinapp.R
import com.hrishikesh.openinapp.mainfragment.clickcallbacks.ItemClickCallback
import com.hrishikesh.openinapp.mainfragment.datamodels.LinkModel
import com.hrishikesh.openinapp.mainfragment.util.TabSelectionEnum

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyHeaderItem : DataBindingEpoxyModel() {
    override fun getDefaultLayout(): Int {
        return R.layout.recycler_dasboard_layout
    }
}

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyGraphItem : DataBindingEpoxyModel() {
    override fun getDefaultLayout(): Int {
        return R.layout.recycler_graph_layout
    }
}

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyRecyclerBottomItem : DataBindingEpoxyModel() {
    override fun getDefaultLayout(): Int {
        return R.layout.recycler_bottom_layout
    }
}

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyLinkItem : DataBindingEpoxyModel() {
    @EpoxyAttribute
    lateinit var linkModel: LinkModel

    override fun setDataBindingVariables(binding: ViewDataBinding?) {
        binding?.setVariable(BR.linkModel, linkModel)
    }

    override fun getDefaultLayout(): Int {
        return R.layout.recycler_items_layout
    }
}

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyTabSelectionItem : DataBindingEpoxyModel() {

    @EpoxyAttribute
    lateinit var itemClickCallback: ItemClickCallback

    @EpoxyAttribute
    lateinit var tabSelectionEnum: TabSelectionEnum

    override fun setDataBindingVariables(binding: ViewDataBinding?) {
        binding?.setVariable(BR.itemClickCallback, itemClickCallback)
        binding?.setVariable(BR.tabSelectionEnum, tabSelectionEnum)

    }

    override fun getDefaultLayout(): Int {
        return R.layout.recycler_tab_selection_layout
    }
}

@SuppressLint("NonConstantResourceId")
@EpoxyModelClass
abstract class EpoxyCarouselModel : DataBindingEpoxyModel() {

    @EpoxyAttribute
    lateinit var data1: String

    @EpoxyAttribute
    lateinit var data2: String

    @EpoxyAttribute
    var drawable: Int = 1

    override fun setDataBindingVariables(binding: ViewDataBinding?) {
        binding?.setVariable(BR.data1, data1)
        binding?.setVariable(BR.data2, data2)
        binding?.setVariable(BR.drawable, drawable)

    }

    override fun getDefaultLayout(): Int {
        return R.layout.recycler_carousel_layout
    }
}