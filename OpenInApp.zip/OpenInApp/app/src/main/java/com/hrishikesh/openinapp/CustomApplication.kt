package com.hrishikesh.openinapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by singh19 on 9/4/17.
 *
 *
 * 1. QuizActivity Result (done)
 * 2. Make Search RealmRecyclerList (done)
 * 4. Loading on Image (done)
 * 5. Network error in topics tab (done)
 * 6. Scroll in QuizCategory (Postponed issued with ExpandableListView)
 * 7. Improve UI of Topics and  QuizActivity (done)
 * 8. Show empty layout in download when no article (done)
 * 9. Set margin in  error message (done)
 * 10. Look for other errors in Retrofit and handle them.
 * 11. change offset to size of list (At home)
 * 12 Margin in quiz options (exponent is cutting) (done)
 * 13. Remove \ from TEX
 * 14. Unable to start activity ComponentInfo{free.programming.programming/free.programming.programming.home.Ma
 * inActivity}: java.lang.RuntimeException:
 * Parcel android.os.Parcel@a5209c: Unmarshalling unknown type code 51 at offset 228 (possible done)
 * 15. add margin at top on recyclerview  (done)
 * 16. change color of red in quiz
 * 17. chane python code to check for page_id while creating sections for a page (done)
 * 18. Snackbar on removing from downloads (done)
 * 19. Download doesn't get refreshed (done)
 * 20. color to set on recent background #e6e7e9
 *
 *
 *
 *
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.org
 * 2. Change all pages of cdn (done)
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.org
 * 2. Change all pages of cdn (done)
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.org
 * 2. Change all pages of cdn (done)
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.orgn (done)
 * 2. Change all pages of cdn (done)
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.orgn (done)
 * 2. Change all pages of cdn (done)
 * end tasks
 * 1. Move Comments.php to GeeksforGeeks.orgn (done)
 * 2. Change all pages of cdn (done)
 */
/** end tasks
 * 1. Move Comments.php to GeeksforGeeks.orgn (done)
 * 2. Change all pages of cdn (done)
 *
 *
 */
/**
 * Future Changes
 * 1. Open Images without HREF tag ??
 * 2. Can Show already downloaded image in TempImageViewer
 * 3. Can Download images async without webview and show them differently
 * 4. Profile Changes
 * 5. change admob id
 */
@HiltAndroidApp
class CustomApplication : Application() {
    // Called when the application is starting, before any other application objects have been created.
    // Overriding this method is totally optional!
    override fun onCreate() {
        super.onCreate()
        // Initializing Realm and fabric (only here)

        // Called by the system when the device configuration changes while your component is running.
        // Overriding this method is totally optional!
    }
}
